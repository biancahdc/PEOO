
public class Calc {
    public static double soma(double n1, double n2) {
        return n1 + n2;
    }

    public static double subt(double n1, double n2) {
        return n1 - n2;
    }

    public static double multi(double n1, double n2) {
        return n1 * n2;
    }

    public static int divi(int n1, int n2) {
        return n1 / n2;
    }
}
